Happysugar HP 導入事例8業種
共通画像サイズ: 1448 x 1086 px (4:3)
WebP形式。既存の preview-business-redesign.html の data-wide-case と同じファイル名です。
GitHubのリポジトリ直下にZIPを解凍して8個のWebPをアップロードしてください。
表示時はCSSの画像アスペクト比を4:3にすると余白が出ません。

※掲載の効果・金額はモデル試算で、実際の導入実績ではありません。
